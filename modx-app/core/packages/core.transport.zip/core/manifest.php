<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modNamespace',
      'guid' => 'ad30fb78895755a3906981a35e295b6f',
      'native_key' => 'core',
      'filename' => 'MODX/Revolution/modNamespace/4b59ee8889be380f6d6c41ad81e3acf1.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modWorkspace',
      'guid' => '764ca1e94c1fd5882a68cc9ed0bd7e39',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modWorkspace/898ddb2ab0423c32f426c620dd793194.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Transport\\modTransportProvider',
      'guid' => '0cbe9db7d51b1c992e16854824afd5a1',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Transport/modTransportProvider/21ee90dbffd766208c7f120b6f668c70.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => '3c954227994db8e65b0886acff40ed3c',
      'native_key' => 'topnav',
      'filename' => 'MODX/Revolution/modMenu/2ab5a8565b0e35ad0405f5d36db23298.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modMenu',
      'guid' => 'c211ee1cc648b91edf5d4493f549d68f',
      'native_key' => 'usernav',
      'filename' => 'MODX/Revolution/modMenu/6f22fcdb5d8fd032937b67ca17c3c4f2.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '83dd2c6bdf0aa81946a7ad2c2b0a439a',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modContentType/013d9786eff3f0b7190220098d66a2c6.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'c0933f578825c7a142a44484529b592a',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modContentType/196056b20372175fd6da677875644478.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '970a8858577bce430533b79a6d04a88f',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modContentType/71b98fd6411337ee1f30f1da8e514648.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '375fccff852ed4745c9f4675dabf5079',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modContentType/a394996cb910806aa536531087206f21.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => 'e8155ae3d59cbf2b8b3816c6f0005364',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modContentType/21c18249acca7d511aa64cdb31e97827.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '67271ee6696730b5bd4328aa4a738152',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modContentType/7cc574aa6bfc866b178c44c6b7f622db.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '75534892aa90a08672c9bb1c98f2fbe6',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modContentType/daa5913ce90f8466e368e3fe73fda60d.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContentType',
      'guid' => '075e1fe34b40624acc50537048c170ff',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modContentType/4c3507a309a3d91c189cf862d75706bc.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '31f13da23c1be91d9478bf5a747ecc30',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/21ea7966e986914c63394e42329e4dda.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f10e2e715eb2c7bf9c4f4840a6d22ff7',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'MODX/Revolution/modEvent/a3ce9ac63516670db3c9c2ed2fd17c50.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb78daa2c087d6399dfefd01acccf92b',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/b6c10c9f87ad98147ff4c6029ef9b4cc.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'be66ae762d515b734aeb2d7763b8adc5',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'MODX/Revolution/modEvent/a992a2a844cf4681d530e582838e4848.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bcad0848784ebd5c17b97588911364d4',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'MODX/Revolution/modEvent/364fab449203a09d8f72db546c09cfe3.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6023c633ca41921a37513c3033f21a95',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/0bcbd09f78bacd78d9b3494d18684746.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f81b3029ff11cf449f56e87adb581d1b',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/ee63555c986883a527469991c2a3fe7e.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd781546100a9895555bebfd05415040a',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/443645f8cc538a89db151cd61a30d9b1.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f62400db8221d9ed985bdb75bc6d89fc',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/5771192db4da0254fa85e24616a3b224.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '2246b65d1c86818fbc219f7753f7b45f',
      'native_key' => 'OnSnippetSave',
      'filename' => 'MODX/Revolution/modEvent/790fad0d45470333c47b34045c75dcb5.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0472029b3b19140b9e4ebc26677328bd',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e6de82672aba8d96465141a740b4a07c.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '358b1608e48b8ae65ef1fc19e037662c',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'MODX/Revolution/modEvent/f69379472fb0e09da52431a3c5024951.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5c463502fba4ff2c17903b902e1a0800',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/4563a882738502097a46e13d12388ba2.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f9849b59b8718625a6dcdf35c0eb97e8',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'MODX/Revolution/modEvent/785c9d6fefd5f23e1480b791dbb4aee3.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '188ea1f3c8b755e48f56f8066620e017',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/6c2b405f4b15549022c21d20d505b3ed.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f66de37687209aa2b3d047d968b6f3d5',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'MODX/Revolution/modEvent/0c02824169e5314d276e1aaf9cc2e95c.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f6d2314d7cb635fbd2b5a323dbcff234',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/e228af256ae4bcdd6c366b482ec395ad.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9938d5295cf45500181b772fb7a865a9',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'MODX/Revolution/modEvent/bd4ab9d55931e0fd3a4c091b63de4ec7.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fc0d73f5f6b541e023497c62d09ec321',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/716ee454b5282b98df65953ef57d17af.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '971fb3a13a9d42f066857a507f6d9fd0',
      'native_key' => 'OnTemplateSave',
      'filename' => 'MODX/Revolution/modEvent/441d140408e8d5bf195832078d83194e.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7153aa3308c9ac580e9ab499b89393b8',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/6c8417ff8ca16fb4f10563266ea774f8.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ca74dea0301fa843a7eab47a2043470e',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'MODX/Revolution/modEvent/cb0e6f1fa254be3bc4e6a905b5e0d91a.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '92945552c5e93251d626dcc9c2305840',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/541396fff135cb97f9d9d2d08c8afb29.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '936ef4bb9dcfafe4ca5d6bcf1942b7a3',
      'native_key' => 'OnTempFormRender',
      'filename' => 'MODX/Revolution/modEvent/aca8a4013d15b5ed9b5c9c3df779c4b3.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4a6a0f35ddca0c9cfc85ed5549597a44',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/c9f287eee9124a073360dcb86920d274.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a03e2df872eeddb3c83135547dea5559',
      'native_key' => 'OnTempFormSave',
      'filename' => 'MODX/Revolution/modEvent/82ee4cce913a6a8a0b2fd762a98e4932.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e02d81587bfbb9a0aa4b98e73ddf165e',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/f856d519806858634f74d4f23dc1be9c.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '242e6b29a58a7cc104427e71a396156f',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'MODX/Revolution/modEvent/74149e0960e8f649436cfde5334f23d8.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '020d298304d61d245b614a2dcc09b0be',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/680b4999939105dec5d536d252b49dbe.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25109b174a9997500c25c9e3327a3bb7',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'MODX/Revolution/modEvent/f25464a0a2c7961278840b0cd148ef45.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6c0d298a087b613ee5037acf3d2ffa1c',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/c7c7af72390c7c0db00e8c38586c7d5e.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '973ebcc1c73b59d287b90735d8f10d29',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'MODX/Revolution/modEvent/7d9883645b95e1f79b5b6e72bdffa5c9.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a832936d77d856c2f53576ef6351f819',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/8c666e0686714853584ef6e152d7c530.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0fe0d863e98490bdecab837f8f50b348',
      'native_key' => 'OnTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/614f56cff67e6365803960d6df892fd5.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5428dac58a48f12595c999c56e0c6efa',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/1841b983f5eb05222535dde735e21a0c.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0c242347ddc10f6277ba8840f711aa8e',
      'native_key' => 'OnTVFormSave',
      'filename' => 'MODX/Revolution/modEvent/d5a073a8cfc84e1a070e8a31d9edceff.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e38683442077f195b11642dd6e897b73',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8d70fe6e08b2e10cb4d4cea666f3f466.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b07dc8bd0f5d80d56c2904825a3f1dc4',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'MODX/Revolution/modEvent/78daf70cd35572d4d074051ca2fde973.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b211e340505e8083f961b77dcb7f6b7b',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'MODX/Revolution/modEvent/fcfce3bbdadcf8d36d66a2c6b6ae6e94.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '187901d77420c29ce17b7e87de8deb80',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/abdec84cfbe2cc0e65d2856e763783e8.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f2f25d859b0799a7145be0afe53dec56',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'MODX/Revolution/modEvent/3173fd00fa36608f2e8d1fb17ac9da7d.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7fb5288f5cde4bfec591e04a89213183',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'MODX/Revolution/modEvent/e5730e91b23830fb2d936911d1758c06.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b4d18e242b03c63a88a22391228a159b',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/162c172688eb0538cfa2dd7777cad908.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0628036cdf3d999d5f339a1ba0337add',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'MODX/Revolution/modEvent/f79ed9964ab7c7ee03080f3142d61b1c.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0ec19949a82aed2c1c55b5beb3d17c30',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/039c4c4b183d655e1080763ada7fbe57.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '40dcf163866997c2637adce9e1923a0e',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'MODX/Revolution/modEvent/e3b5886c275f7f722ef96ce77ab5a817.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a37481d71368a74463f85897e9f6bb46',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/6f9416ddde7ecf828c6cbfecd6f955ac.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f45d32e0506c72c648220f5f12211a71',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'MODX/Revolution/modEvent/76653d73bfe6bca5c0ab1d348be88362.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '30e16d3c93a498ec0d04136d8f6009b9',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/e01d9c873bb02a64d9531f492739fbe1.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '50e64e41b3f989a8a0849d8db07990ba',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'MODX/Revolution/modEvent/33977f399f6a0352280fa71f47222da3.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bb2ff88870a48c0b8f46c59e71aadf66',
      'native_key' => 'OnUserProfileBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/e0bcdc25914135c04c3d88899afa8981.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '672f22998997f34f595ad7fcc5fc0d75',
      'native_key' => 'OnUserProfileSave',
      'filename' => 'MODX/Revolution/modEvent/f847cbdd6816b85ee934b35783f60a82.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '779027bf6fda51329b865d3fdadceac3',
      'native_key' => 'OnUserProfileBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/3bceca7792fc8ff59b5db15445a1c6d9.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'db9a14c2ba74d1e9d38da1bfa5ed9e53',
      'native_key' => 'OnUserProfileRemove',
      'filename' => 'MODX/Revolution/modEvent/e625aad4b21a0d5614978de256a1f190.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b050dc7e773a9e9406a2db0a64c75662',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/71e0a06bfafc8961494452e4b2fe5d0f.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6072da78c02c480a2f3c1bc8642e7cdc',
      'native_key' => 'OnDocFormRender',
      'filename' => 'MODX/Revolution/modEvent/cc0eb31f71c657a749c79a8603cafb47.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f5f53a1059fa36545750503dda4b61a2',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/9b4366e228ad727786099a22d34e6bd8.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a092fa71e2edf33af59212795a09f6c3',
      'native_key' => 'OnDocFormSave',
      'filename' => 'MODX/Revolution/modEvent/d74910ffd4f8ad364489c326b3bc374a.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1558d0c76a8c205f433b5afa412ad905',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/7d9825d6b55850532a941669fd4934eb.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '864bba1a0379e0e012b39b50e7598157',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'MODX/Revolution/modEvent/81dcafa5298b3543e46d93b47eabeab4.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b77081ad98533fb052ecaf78fe4f1758',
      'native_key' => 'OnDocPublished',
      'filename' => 'MODX/Revolution/modEvent/da1156da03cb3181684db8b5c5685570.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9dac318816a57bbf889dc441bf08b91f',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'MODX/Revolution/modEvent/7c8203667c3ee474068b7bd7893e2cdd.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ad014127af1cc2f1bb969de0c854145c',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/3f974752c32177113862f2e2719e2d1b.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6edd390e97848b6ddc4112226917993e',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'MODX/Revolution/modEvent/019fd0627df2328d0d26d0faaefbf9e9.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '186ef61264fde9c966217f0277c0e981',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/bdf7dabf0d59712c523fc924c45b584a.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'd3df26656d35b0705281e64b8f9be883',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'MODX/Revolution/modEvent/1b9ebb7128cc4b839541a997d21b766a.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6f5b578c76718050cace5d622ac02d0f',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'MODX/Revolution/modEvent/9d55160b7bfaf7e6b9ef43ac12cb09f2.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '84b4afba61a5e82eb331a29285751bcb',
      'native_key' => 'OnResourceDelete',
      'filename' => 'MODX/Revolution/modEvent/b91a89271ce0108af7ec7c837cb48506.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'efe2110c5f5634fc18b166dbacfe47e0',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'MODX/Revolution/modEvent/09a380723170304a5af6e7be0ca0751a.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7ef7acd784adf98caaa35165f58ddadb',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'MODX/Revolution/modEvent/9cdbe296899dfa840ef49776156b727d.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '02296a1ee54d1db03caabe4cecb66f9a',
      'native_key' => 'OnResourceSort',
      'filename' => 'MODX/Revolution/modEvent/14cfc52d192e38d7aae29f912b56e43d.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '04c16e811ccb92b337aaad4b61aa22bd',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/8686b1803215aabf4ba0aff4f5e433cd.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9745ea88c0432f35349af4dbf6f67fea',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'MODX/Revolution/modEvent/5c656c95f58fbfc77af9d42fb0fdf538.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ed74ad974d2fafae84cc99d39c2900a8',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/f3858380091fed51f20faa59ce327afb.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8261b235861e4ed983ec4fa70f101401',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'MODX/Revolution/modEvent/29ed3cb012dac382e2b81ffb1f7c33a7.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ff7a45497ab6b98b381770a481e001e8',
      'native_key' => 'OnResourceCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/eba25e86e4b32485ace1bcf9394ebdda.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '404f0f43e457a6a93d1b58f5fe572018',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'MODX/Revolution/modEvent/4860c8630be3fa9f19763236cc4c9fab.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '97b783e74a65044e846d22e725bc5e7e',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'MODX/Revolution/modEvent/c3e75bbcdec7313517a5125e3bed1de9.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '67a3ed160e16eb0c5f7c3a96e45a57b3',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'MODX/Revolution/modEvent/c4486a4e285732ff10a43deb2657a423.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1e588a061bda40cf0dcb0e46c43299d2',
      'native_key' => 'OnWebLogin',
      'filename' => 'MODX/Revolution/modEvent/158b1a5e58bf64ef64817b46019f28ce.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '115dbf1a3625ed6cc24ba479828c523a',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'MODX/Revolution/modEvent/146f8eaf3f178fcdb4c8ecd29a7e910c.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '20c925e49cb12d7ff503567452c6fcf3',
      'native_key' => 'OnWebLogout',
      'filename' => 'MODX/Revolution/modEvent/c04d3710e4b2f4cd1743ad76a6403a24.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '292e302d0b117ab12fa2581cf9ed444f',
      'native_key' => 'OnManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/846cd6ec9ea804db704f04fe81945dce.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e96edea717ce67c8425f87c114972b29',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/caf20c76a0025c00e1dab12646fe61b6.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3aef32d4aeafce277c5cfac707a747e0',
      'native_key' => 'OnManagerLogout',
      'filename' => 'MODX/Revolution/modEvent/6ed4f68ad7d3bb8633b4f17a2d313a9a.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '83f8d2212ccd607bf12c492293c3af79',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'MODX/Revolution/modEvent/fee3440d288e727f3e69bfc594ecbc41.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c916082210aa8b12d2f21dc6e663601b',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'MODX/Revolution/modEvent/6c3e4b6bccbcf1b150d605c3ad6c2fa8.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9318765299182d333be62b2c44f00566',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'MODX/Revolution/modEvent/04b0cd08262e8f5ec5c4d04e3d6da7a5.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4c6f827c3c20a6862edd08f409e2874e',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'MODX/Revolution/modEvent/3306603038b916bdd02f1843f60ad292.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5cc84d6fcca1fdd2c07789abaf201147',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'MODX/Revolution/modEvent/479d4637c2fc439ed9aad599884b2cde.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9ab174e47decad176dd9f7683c693a2e',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/531c8c967ad5dda0f1d8be43ef0f498f.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '60ec386d0ce63f66afee898d60074ce7',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'MODX/Revolution/modEvent/4b635ba34131d75ce063fb6722faec82.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '44afdeb8427b04ff22a770dcf088554d',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/f5f645081fedfa1d343826fdab23dec6.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '880d123e7c5448a516d7033bece2776a',
      'native_key' => 'OnUserFormRender',
      'filename' => 'MODX/Revolution/modEvent/d2a879348bca2a7a1c2d439906bb901f.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b07affd7ec25e7ff815f5494ac4ccde2',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/615ca1e194ce37c228b96a0035f76400.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8b3fc42147b63de3c71183912578943a',
      'native_key' => 'OnUserFormSave',
      'filename' => 'MODX/Revolution/modEvent/50b80ad06a50085f52ce55720f4685d7.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5a95e5aa6945d5bf395f1c2d3a9b3939',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/3f08fe4d917ff065633f53deab3e9b93.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0cd83b1ad51c9369ce58af63acd0ca87',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'MODX/Revolution/modEvent/88ec3125e8768dde5f7def88b3e27685.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a0db8d2b31809612ab77c51c755383a6',
      'native_key' => 'OnUserNotFound',
      'filename' => 'MODX/Revolution/modEvent/ed6eb9382aac5b57a3646ccc7a08cb81.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '176e7e9108bd96812c26d7921d8b2154',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'MODX/Revolution/modEvent/81553e9a5b3f54715d6c435be6805ca4.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bf2bb761421243b8cd6bfa20c6ac743e',
      'native_key' => 'OnUserActivate',
      'filename' => 'MODX/Revolution/modEvent/20099bb7f518cfdf57e016eab234d521.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '60cf7ad18090714ed0d00e613ea9c6ca',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/4ff0e3f7f7dd9b4a6a30a908a2a2b57b.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '212f68e0309992e78c281c41f6c1e160',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'MODX/Revolution/modEvent/5cb485e62941ccf75b71ce76718bb5ef.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '96775f0d6dce2ddd47de752523de5e45',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/9c6c5ecbf07dee37777df790c56c22a7.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3af7720e0adf9b19e835da805faa8325',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'MODX/Revolution/modEvent/79ae020d842ab48d5871036d9d75adbd.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1c88bf92fab526179deb5baf7c1b1b17',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'MODX/Revolution/modEvent/db71e5db0e289374131dc9687e211ad9.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1bb5ed9c4878f9ccb0ca547e48091657',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/234d111b12e3c7fcbbb07669e72e8dd3.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a8ecbcffd147c3636a820550074a9177',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/df4cc5869f38bb7b01de0c604b3b0a1f.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '33b5ac0cf9d699a2aeb691f88d569d27',
      'native_key' => 'OnUserSave',
      'filename' => 'MODX/Revolution/modEvent/cb5c633000e22a3458d00f3b751e5a97.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ee8a0238fb332dfaa522f36ea57bc0a3',
      'native_key' => 'OnUserRemove',
      'filename' => 'MODX/Revolution/modEvent/2238381a509c3ddbd3a06494e47b808f.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '7f007f3aef7e7dfc0e6084ba101afd23',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/2dc391306ae76c37345200be192d7ed3.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '34a4ff5ab8c05f927fc54548dc3b2cf4',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'MODX/Revolution/modEvent/532c466d0738f2c48fae03b972672401.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cdf4f54b835b410e838f81fc59bbb288',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/3b418f5e5ed0cff462b6d2f28da57b6d.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '186cb6295cea2b8a56338209f40d61b3',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'MODX/Revolution/modEvent/05ad10bb6fa731c5d841bfb94ff6610d.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '932ab99dfa9a996215b55a5c61101c5d',
      'native_key' => 'OnBeforeRegisterClientScripts',
      'filename' => 'MODX/Revolution/modEvent/03beead39befdd14b935c645d553763f.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eb50fa034d1e004e1a7c65371e441989',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'MODX/Revolution/modEvent/60ad5c522b6b697c39ab7b522ba263e6.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '037ac5820fea5fa09c50939b6383dff6',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/112040ba9b7ca821315160ebfa6f59cb.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'deaf280010c9794aa8d7169906632704',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'MODX/Revolution/modEvent/69b76796245e201c5fe4ba84561c03ae.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3146994bc80b7ae9995f90fc61f2191e',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/d3ee869b3a0ec96af39aad10408e4a61.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '923b80ed8145786d347e42325e917c5e',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'MODX/Revolution/modEvent/d395b290a0690de3632642e158aa7b89.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '19545b848cde2efc8547d1c0d7766814',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'MODX/Revolution/modEvent/474ac0fad6c17a1808bc883e4653a712.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'add9a89d7c549f4f072df7f26cd9c7aa',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'MODX/Revolution/modEvent/5f229bcae15d755e054574e3e4c58db0.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f44c3ba79a4842f723a9fa1eebfa8de3',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'MODX/Revolution/modEvent/9197d75452cc6a68938f9c941183c456.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '621ceefbcddcd1a3b85ba0ed5779ebad',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'MODX/Revolution/modEvent/b4837d41d8017ed473f73c6caaafddbd.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a7706c7ca33f59619635be3f9065a101',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'MODX/Revolution/modEvent/b3884877ffe1200f9b00ec4aaca5f544.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '00b491fa0f825a9a21bef3b2e7c1e4c3',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'MODX/Revolution/modEvent/c770c364f524fc5ba0c4622a149c4da2.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '41dd897b6c778c09ca59c5c2dd744be7',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'MODX/Revolution/modEvent/08688e2d41a7fd775d523b1a2bf7774f.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c88e973312f869d2e74a1927050000ae',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'MODX/Revolution/modEvent/0ba0296752c58030d766d97794684b22.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '83b45051d84387f99ea627d4fb190bbc',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'MODX/Revolution/modEvent/452e2dde4fd5dc863d42a7b6b56b573e.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9830aa5970e3664d2c7e1aa2ceb66092',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'MODX/Revolution/modEvent/b687c075dd4e635582783a06594cba8d.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f331c1a506ae3ced760fbf89259147d8',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'MODX/Revolution/modEvent/36169ad0b20e687c12db9d534cc0190d.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e3c968bcc901c7ec85f74a85464f6f7b',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/67418587a5ecacad9372c87bb30a46a8.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5bdefed575e606e060eaa51e27810e11',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/b53cb3fe969c5ad00b462dc83f5de562.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1187c017fbb0a99153950ae07938796f',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/3c93df52ab0acfda7dbeed686e2230b0.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ab2bce6aab0340945b65112955e94f89',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'MODX/Revolution/modEvent/0ffc100e9ed507d5b055fe87ab834a57.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f1a6ae056349d5813ab2e457aefd7c15',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'MODX/Revolution/modEvent/1146acdae2cec42942cf612ff50e8385.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'eb8c43975b5dd8a66f2b92a716afacea',
      'native_key' => 'OnWebPageInit',
      'filename' => 'MODX/Revolution/modEvent/d26ebdfd46f9f29cce921aad2fdbfab1.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f86b9504bab60e6b4759b9c63ffd4d38',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'MODX/Revolution/modEvent/6127d0a9cdcfcfe261d52af69a097493.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bce0b7a267678b1d0684269689e4d4fe',
      'native_key' => 'OnParseDocument',
      'filename' => 'MODX/Revolution/modEvent/8abf417ab89a0cacb574ad1684be69c0.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '28f194ff68d5a1bebe038a3a665973da',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'MODX/Revolution/modEvent/524dd81de44e3aa306517a45d57850b8.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '86738949fd4d96de9c6c8f35be825456',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'MODX/Revolution/modEvent/7e64b663058f95168acfd0783af39b5d.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '5d7067b08cbd5de90c15924a2772cc27',
      'native_key' => 'OnPageNotFound',
      'filename' => 'MODX/Revolution/modEvent/b8720f537dd9695d1ff73e44a27e0b69.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'add34e3b0094b5dd996a126f0948ea6e',
      'native_key' => 'OnHandleRequest',
      'filename' => 'MODX/Revolution/modEvent/c9f6d1aca5bb9a081308a50bebb8fdb9.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b138064a4ce091da79b52896c3971798',
      'native_key' => 'OnMODXInit',
      'filename' => 'MODX/Revolution/modEvent/c2ffc508724b1b6af1acef34baaa64ca.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '09905af387b93eadd3ea18fcda802d84',
      'native_key' => 'OnElementNotFound',
      'filename' => 'MODX/Revolution/modEvent/f7d10dd6e85b4f0eb7c5089fb0fb8af0.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3c448dc732f0ad8c18378a5eeeb18cdb',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'MODX/Revolution/modEvent/1629be75b7ba7c9f7b33c4ae8fd626d9.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3e3720094312cf106e9347e2eef58f38',
      'native_key' => 'OnInitCulture',
      'filename' => 'MODX/Revolution/modEvent/b82afc331d1448d4f2e2a2f170bf03d5.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b35b496a87baec41bec41d3af279a55',
      'native_key' => 'OnCategorySave',
      'filename' => 'MODX/Revolution/modEvent/83d418839f4c4b4a0cb32358c8edf8d4.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a4e822ed93ff1e5eca1bae8ae21a2fcc',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/c6e3e76bd0ac48e7e3a3dfed50f5307e.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '298a5b4b32893d9567f07e0ca3cc518a',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'MODX/Revolution/modEvent/ae31832fa9fcc3c2b64d297b5bfc1325.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '3b46ed999c18343aa36b44bc5ebcb0bd',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/ca35d614d5345697f0a367d3ba0664d6.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc54941d0597b48d2192c597b37b8998',
      'native_key' => 'OnChunkSave',
      'filename' => 'MODX/Revolution/modEvent/8961065605554503c4ed5499e4bee4f9.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'badaf84090e86ff2bac91808e2eb7004',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/b01d61e08e1e78d645e5cd4f18e40785.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1b6b4c8b20f196f1600ac918b2d6acd0',
      'native_key' => 'OnChunkRemove',
      'filename' => 'MODX/Revolution/modEvent/70a3f73646d89e1e545a9aa0ed6476d8.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a1a876e2a1d60efad570ca40afabf615',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/e200a8676c62e905ae0338ff4a387dd3.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '533cc4e830cf52b79e9bb683e7c3c54f',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/5ad5f4addf07d603195a5654f0bff065.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8ac3a1caadc21a01396509d2b0b66a74',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'MODX/Revolution/modEvent/8587358c56b88613d55df2fb10827ae3.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '97eb19e5d1a6653d2b15e01386a13aed',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/31413baa7a67cc778a40567bf9533882.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'bc146cf5c2e388e7f667b4a7884bc426',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'MODX/Revolution/modEvent/3f9965567963a9d5e0456efb76ae74ac.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f38f138d64f2df686db9f20860c367ea',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/6a59c04af60761a01b6f7023ddea25ad.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'c9234be7ac781f70faae57c5463bad5c',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'MODX/Revolution/modEvent/4bc169f6a72b1a8ec44f42b3347427de.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f1c5b627a59d1572c4ef16618d7a5e4b',
      'native_key' => 'OnContextSave',
      'filename' => 'MODX/Revolution/modEvent/475a95b2c099c7563788de635ab11321.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '72c14e41da4cd551c77ac179f63aea41',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/7426b9df585d87832b3526b2a4081128.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '8f6afbf24737bdecbe4f5582e7b9d8d7',
      'native_key' => 'OnContextRemove',
      'filename' => 'MODX/Revolution/modEvent/85a6fe64f78071022d0e0a60f99ce77c.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'ebb254a284f1453755cfe81453505e25',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/5f1d25c0978e054820e6483aeb49ffdd.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f72ae49a19289f9714cddf19f48e25db',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/51872c2744b63f359aea1eb2819af446.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '25befadf3dea0f6c1d5c29b27d18efb3',
      'native_key' => 'OnContextFormRender',
      'filename' => 'MODX/Revolution/modEvent/19b4db64ef87b723ba4d006f63017d46.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '94cd98811531c31f563d5ead90e96677',
      'native_key' => 'OnPluginSave',
      'filename' => 'MODX/Revolution/modEvent/2de2ed3f67b14ecaf960d05b2dd22f84.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '1bc7070b0f97a9eed10ff38ab802c9d8',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/469db634c11560a694e36db5af6876ad.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '6ed450d46ba48375e62e8671a5f66959',
      'native_key' => 'OnPluginRemove',
      'filename' => 'MODX/Revolution/modEvent/d55e08ea7879a0f6f76f8c2ed4c7a127.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '83987e77543e3dbcb8dece0ee03e18ce',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/293c3bcdc63453b4855669a2e4adac1d.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '0e6715a9e7e2015ee48015812311b6f5',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'MODX/Revolution/modEvent/28fefa3166ce1964d8f869e90aefaac6.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '944292fa04157130da02b488e0344988',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'MODX/Revolution/modEvent/a11423d351a1830e2c78015e03af7a13.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4b5da76e7a411e2431ebd5b628016eee',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/c8b5fb791adbf233b19365a1be8057b5.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f7e614e1e965cd847f0b7d35bcecfa60',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'MODX/Revolution/modEvent/df664e957e3b0e6962b350d974260ad6.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'e33b33e081246bc26f81de3d290f922a',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/8289e0de74ace7877040f31d5cc81fbe.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'b4bbe1718f0d1a059259647ad38c2ce6',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'MODX/Revolution/modEvent/b69066d0284f17f98905ca06c5db88c9.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9d50bb01e5f75c32608b590dca6ab113',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'MODX/Revolution/modEvent/3dc9b28ba9c231d3760415e2f2a70709.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '88eeba2e00ac18e561d8468135bfc888',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'MODX/Revolution/modEvent/01b710d6ac85e59db3033a1bbf8aa78c.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4768b0eda2b6050dfb6cc7d176ee54ca',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'MODX/Revolution/modEvent/4ce4f8ed8782cb527494dbca6f5512f7.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'a39bf9e51860e21c0ba06c64943a9b3c',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'MODX/Revolution/modEvent/89d05610899b0ef3eb9e5a0ead562c62.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9b982a0a2a706be92dabbda7d3a5ccb1',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'MODX/Revolution/modEvent/3cbb4e4c8d763966b986e99f78af365a.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '9593e49bd057c27c6b3e712757f70430',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'MODX/Revolution/modEvent/430b0018a796b7e4d8c0164671f6f97b.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4f29da25dc221f6b7bf24a7189d5087f',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'MODX/Revolution/modEvent/751b646a195e7e076bc63accafe2f03f.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f51222de6b6c69f8dcc141136f806f8e',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'MODX/Revolution/modEvent/46a526bdd5e5ab66e54f8fb9e0847dfd.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'f636d5a6b66444c6cde450fe593e37dc',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'MODX/Revolution/modEvent/cf834c594c17022f479637b456a953e7.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '4e33e7e1692fd7854271fcfc9fdf3781',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'MODX/Revolution/modEvent/5a49024f15d8236e27f0041302d57a5d.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'fd9ece52ec92a6e730793118a7e0b4b2',
      'native_key' => 'OnPackageInstall',
      'filename' => 'MODX/Revolution/modEvent/fa575b2553079cf72b158ca92baa3304.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => 'cf3c6dc8a313debaf06020df8075787b',
      'native_key' => 'OnPackageUninstall',
      'filename' => 'MODX/Revolution/modEvent/19774e660779a0f0751b4494d5fc1783.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modEvent',
      'guid' => '94d99557b4cbd8f41385d76b7cbd010e',
      'native_key' => 'OnPackageRemove',
      'filename' => 'MODX/Revolution/modEvent/9565b0f81988e8803d3361dfc1740aae.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '805d8eb1b263e6438c5c5cff6c4e9e3e',
      'native_key' => 'access_category_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/24fbe1ee8a5c7539c3fadc42142d373b.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '60b1b35511b3f1d7111fedf7f0d78832',
      'native_key' => 'access_context_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/b3e3f99aefaf434c92f9145a1e91c892.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9a72fdd3e2b5d345eacf036bf760eb61',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/b9d699abbefebc0d0c758918f39fd31d.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4060495087aa4877fc02e0b3152ce94b',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'MODX/Revolution/modSystemSetting/0d366701bd904f50f8763aa63582c2d2.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '965aed5cf805bdec82fe6454cd8d42e1',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'MODX/Revolution/modSystemSetting/66b5d920fb3bbccd55d2d10af4837306.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'da4ca280bdf4a6dbd345abf72efe8dac',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'MODX/Revolution/modSystemSetting/1efe0a5d5f93e1b9805a202cc95666a5.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a4e1218edb7a2f5a56276f9cb10dd403',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'MODX/Revolution/modSystemSetting/92d90daf3170a13ae1065a770f84eba9.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '23f713979f8f2cab5d557659610e823d',
      'native_key' => 'archive_with',
      'filename' => 'MODX/Revolution/modSystemSetting/aa529f90d32fe7b3af72aa0b6eba4e39.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2b98481e9b1e23f0a79b9e60d8d2bde7',
      'native_key' => 'auto_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/69cc280f3d33527038c38359482dfdae.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ec12bfe9f6d459a213716951f4cb8bf',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'MODX/Revolution/modSystemSetting/d5b39dd252276865ec2a09b22e738e8e.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ac42040cb5c8da2541f7af6315495e7',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'MODX/Revolution/modSystemSetting/c1e2fc1f64469351cbd53dba02c83e36.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5dee3b305a14af04a55dee122e63b095',
      'native_key' => 'automatic_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/dffb3a7fbcb66ac05a66e5332d9bd8a0.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3444915b68c1904813a5d5dc4acdf8b3',
      'native_key' => 'automatic_template_assignment',
      'filename' => 'MODX/Revolution/modSystemSetting/f0170ed3858460dcbfbdc2ebe9519dbe.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e465248a535e7706ddbb7e1a5dce0d0',
      'native_key' => 'base_help_url',
      'filename' => 'MODX/Revolution/modSystemSetting/e0092ae249e514f2e136474976cffd15.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '499dddf749315c720bc37fd0755bb506',
      'native_key' => 'blocked_minutes',
      'filename' => 'MODX/Revolution/modSystemSetting/7da0d5e745af6c3e14a1a7f279793b16.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50ac0eef965e4366caf53bf515b6590e',
      'native_key' => 'cache_alias_map',
      'filename' => 'MODX/Revolution/modSystemSetting/8191143550311abcbcef96d6de3a8c43.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'eb75ca75d85dc545df369475e634a224',
      'native_key' => 'use_context_resource_table',
      'filename' => 'MODX/Revolution/modSystemSetting/56de7546830aebc9fb5a1f8d965bd724.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fca99651c1b73df7308ade5581bce381',
      'native_key' => 'cache_context_settings',
      'filename' => 'MODX/Revolution/modSystemSetting/c1f016b0e9f6d17299e5de21b22b6a21.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4a34b9ecc99db4fb4a237668a849f2a1',
      'native_key' => 'cache_db',
      'filename' => 'MODX/Revolution/modSystemSetting/1d210e59f70107f2ccfb687e276ed26f.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '33ffddee4bf4881b1d7074c6fac95e7c',
      'native_key' => 'cache_db_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/155ee3d29c9bd52f9472eed492b8ee5e.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cd8dc6e921fd10a9a02a48f6409a5964',
      'native_key' => 'cache_db_session',
      'filename' => 'MODX/Revolution/modSystemSetting/b0a2f331bb929cdbfb814e2c95e62f89.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f691c1ac6cf09a3fcff7574532dee82c',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/91b3f2f6b2cd64fe0a4dbe82e4cd703e.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32da825be27e2284b3b494c450644bba',
      'native_key' => 'cache_default',
      'filename' => 'MODX/Revolution/modSystemSetting/7b26716873ceb47e6221d997516e6376.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '117e9542943840bcf4c81f5653fd0ccf',
      'native_key' => 'cache_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/c569d733741548af814b8f4a0e2e90c0.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '938fd91ba9aab252fd65be6c5ebcfc89',
      'native_key' => 'cache_format',
      'filename' => 'MODX/Revolution/modSystemSetting/679079e1c0d52ea0652ff326b3941693.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '730f8d8b7e95b8db03095975e361b11e',
      'native_key' => 'cache_handler',
      'filename' => 'MODX/Revolution/modSystemSetting/c74835dc0cc2c38cce892077e8ed7f13.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b15a1fbafab5d5d83d304ab99b2736bc',
      'native_key' => 'cache_lang_js',
      'filename' => 'MODX/Revolution/modSystemSetting/f70f56691f9ad9cf4090f764b1979289.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9c987294af916488322b2c01893bc398',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/529cccfd8fa1985d19bce8ab2a2dda75.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b4116ee1181a5d9e86e7398208e929c2',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'MODX/Revolution/modSystemSetting/a69ac1ebac71d9fe9ecd2f68d8473e08.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '697b942db37eabfcc7e3526c840b7f43',
      'native_key' => 'cache_resource',
      'filename' => 'MODX/Revolution/modSystemSetting/da0ad34741b955bfe2018aabd9b45c75.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f262fb00fdcf5a5220af0fae7b70541',
      'native_key' => 'cache_resource_expires',
      'filename' => 'MODX/Revolution/modSystemSetting/d5e5bddb2889f43cd7289cda3e9e5bc4.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b2f46aac9f9518e6952854e930555386',
      'native_key' => 'cache_resource_clear_partial',
      'filename' => 'MODX/Revolution/modSystemSetting/a90112bfe245926b10e03ce408d26290.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '75aea10c828c692310f5008e990d1633',
      'native_key' => 'cache_scripts',
      'filename' => 'MODX/Revolution/modSystemSetting/d3e63117b34c0a8618e0fb39b84c0d64.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f14ffd7d4029c1917621b97ed86d84d1',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'MODX/Revolution/modSystemSetting/f9d9a91652ebc6f155b9974e432fa269.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd6b81654235775c582aaffc3e12fcfa3',
      'native_key' => 'compress_css',
      'filename' => 'MODX/Revolution/modSystemSetting/f03071bd01f5a0a187db3149b7c3f2e5.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bed42044befc2334805f7093dc4ab217',
      'native_key' => 'compress_js',
      'filename' => 'MODX/Revolution/modSystemSetting/ae1d67647dc7f46a498cfe6117ac1843.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c978ad8599628d717c23209199f1de87',
      'native_key' => 'confirm_navigation',
      'filename' => 'MODX/Revolution/modSystemSetting/81ebd96f5832de3a24f931764de32bfa.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '996d50ef6c74eae0565d7c8c1b5add56',
      'native_key' => 'container_suffix',
      'filename' => 'MODX/Revolution/modSystemSetting/f422ef9e99c8f9e72b39f553eeef2a85.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c733a3a5bd72e15a06f9b9489fefae99',
      'native_key' => 'context_tree_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/a44df636e9420b3b4f5dacb24ec43735.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ae6c9c6ecd7fa9c52284928fadffd2e',
      'native_key' => 'context_tree_sortby',
      'filename' => 'MODX/Revolution/modSystemSetting/a390fd661555135d080c4ddb9094c963.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd31aee6f7506f14bf4b9e509fd577371',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'MODX/Revolution/modSystemSetting/67bceee20b5b71eba2a4300656d88399.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef6814f29421abb1039ae413affcc8f5',
      'native_key' => 'cultureKey',
      'filename' => 'MODX/Revolution/modSystemSetting/4654dfb07a26ad76695afe8be1e3c7a2.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6068bfdac82a7519b83ca0bdb5c95bb6',
      'native_key' => 'date_timezone',
      'filename' => 'MODX/Revolution/modSystemSetting/943db421985b7d737f8fff94d915a4b4.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7e939970b40eb228770787855014c216',
      'native_key' => 'debug',
      'filename' => 'MODX/Revolution/modSystemSetting/77df1f7ac5b70cac623a43b582819bc9.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1a40c7dfc730ec73526d29025b113acd',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'MODX/Revolution/modSystemSetting/ff68393ede40b749680caded8305930a.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e33896aa0febb71c22f7c57d510f693',
      'native_key' => 'default_media_source',
      'filename' => 'MODX/Revolution/modSystemSetting/8be0304517f6077bc16dafbbc08e651f.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8da7bc46f95f39fa895fab32f6b1751f',
      'native_key' => 'default_media_source_type',
      'filename' => 'MODX/Revolution/modSystemSetting/d8fc32cddf24944d9e0cb162bcd936b4.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08b5a83eb0419b89af1c120d4dcf9e7a',
      'native_key' => 'default_per_page',
      'filename' => 'MODX/Revolution/modSystemSetting/135f300d68cbce4af9ce1f36d93ef131.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd48d097904ae6c9517f2815b26c8aad9',
      'native_key' => 'default_context',
      'filename' => 'MODX/Revolution/modSystemSetting/d7c81e7d101062e52fcb9d1fa30332fd.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bcabc0ddca5a051298ac54fedc335984',
      'native_key' => 'default_template',
      'filename' => 'MODX/Revolution/modSystemSetting/3d2d196eef99acc0841a3fc5ef503e3a.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '52cb56914874637f4905be0129ee6933',
      'native_key' => 'default_content_type',
      'filename' => 'MODX/Revolution/modSystemSetting/4eff031b8196427da6255d1d5abe137f.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef765cad9a6b2f6bfbb57d995777c1a8',
      'native_key' => 'emailsender',
      'filename' => 'MODX/Revolution/modSystemSetting/0fbfefc250a913e960d0e3fb889969c3.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '08a8719e0cb57d1bb1b60ad98231ddf6',
      'native_key' => 'enable_dragdrop',
      'filename' => 'MODX/Revolution/modSystemSetting/1145898259d81ebb33da9c9a9e99ff0d.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'babc742df5e203fac8e03ccc23e41102',
      'native_key' => 'error_page',
      'filename' => 'MODX/Revolution/modSystemSetting/ef343c71cc11f9dc7870b44c124df566.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '17ed77a2146091ca4bd63d73358d5970',
      'native_key' => 'failed_login_attempts',
      'filename' => 'MODX/Revolution/modSystemSetting/0194a196e17fad15b034f8c0a388f196.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ac8cd5f3254ddb7d6355f34c3de101cf',
      'native_key' => 'feed_modx_news',
      'filename' => 'MODX/Revolution/modSystemSetting/7b3872ad7c9a02a74d84d836bb36d788.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '79c21d01231f489477a9d9bf142861d9',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/4057bf0d743d9c28ab058c06b43c82a5.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3011ddb134cb77aa6de2526d1828af21',
      'native_key' => 'feed_modx_security',
      'filename' => 'MODX/Revolution/modSystemSetting/3f44a49676d50063c714ab4b452ba39f.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7687dcf6849fd0f815368a74de7c83ba',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/2402cf2b9e088392bfb2ae897a168df5.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '902ac5c234c0fc21fc09127aa727692c',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'MODX/Revolution/modSystemSetting/e29b85180d7c0648271be9cb9c2f947e.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '71f39f472734fdf5ecb7400cf4720b26',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'MODX/Revolution/modSystemSetting/2937fa3f9373f8a0ba4cb1a573c59cca.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2c54c8834db1b1a8a0068d6d3091a00f',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'MODX/Revolution/modSystemSetting/2c26d2fda3795c49b98e00f127fc966d.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '376f9d43ff033d23a611dd699b05cc5c',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'MODX/Revolution/modSystemSetting/3a76396081ff8abf26e3bff7e77f5aa9.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9979740e8d10c2c2422e277bda409bce',
      'native_key' => 'friendly_alias_realtime',
      'filename' => 'MODX/Revolution/modSystemSetting/b78335b049afc9f5ae53921f7a84c660.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a74a97a67a6494dc388280c9544a032e',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/f23cae1552b24cf37d202c3893027ca2.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c9e05785e74f1c438c401238adac99f0',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'MODX/Revolution/modSystemSetting/b5bc403dca1941ee9b158fee24eba249.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '672aafa807edd5b930c46970dc4761d9',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'MODX/Revolution/modSystemSetting/e78af60581b33147cb6288915c456fe3.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '03db7ac876eb479d99a5fe21bc723284',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/ebf10079d2e2468c39bac14953e1c0f9.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3e2e3af4c2f1913b4ad6c4b97d12d36d',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'MODX/Revolution/modSystemSetting/918e82aeedff88aea725f5b74d29dc32.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ef4aec39834528b537d47f79f9266cc9',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'MODX/Revolution/modSystemSetting/b3e48c2d2f8563a400839576f818dba2.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6d50cfbcf48aefcabcf76f90ca85a1d8',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'MODX/Revolution/modSystemSetting/7ce31bf3220d8374156a1f34cef36150.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e685f9980a81c1e6d0e39f13b1a0ef35',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'MODX/Revolution/modSystemSetting/0aa74e263763e70177497a64234e9840.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a8665311e8f54482e60aee657ebefdab',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'MODX/Revolution/modSystemSetting/3855ce9952f3e52a288a654a155c23e9.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '31a665d8b7b7ed1adea2394c79c65a7d',
      'native_key' => 'friendly_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/2af5a5b1e866fb8cba390a8baa8ca10c.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4ec7ebc58014890f6c221723242c9aef',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/f7a13f3b672b4237dedd2507439439c0.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '165b370b73d928e8ccfb170d823f7c49',
      'native_key' => 'use_frozen_parent_uris',
      'filename' => 'MODX/Revolution/modSystemSetting/729e9461626ea9a8c79e85af03b89bb4.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e4b9bff9a4b64e87bc4f4c0e8e7c2b9c',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'MODX/Revolution/modSystemSetting/ffd7dc2276325954603d239396b47b91.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '348f7b070002f1a7fa3a405e597412c4',
      'native_key' => 'hidemenu_default',
      'filename' => 'MODX/Revolution/modSystemSetting/991319bcff429a7e81873c1bc6a80629.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20cdf718980341ac67b5d33ed54ee602',
      'native_key' => 'inline_help',
      'filename' => 'MODX/Revolution/modSystemSetting/57ef88b66880be24af5b52f4e307fc2c.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '64b0d6865de5d26d5b465257be410886',
      'native_key' => 'locale',
      'filename' => 'MODX/Revolution/modSystemSetting/1cd5e3a7d54871950ab252b7e2786a14.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6a6356fd59f88c681acd2941fa99144b',
      'native_key' => 'log_level',
      'filename' => 'MODX/Revolution/modSystemSetting/b34a9e95f8c43346ba6ed584ec6ffe5c.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e778ea757f190b6b9047e8f0a66053be',
      'native_key' => 'log_target',
      'filename' => 'MODX/Revolution/modSystemSetting/8611a4512297a7b91de51af97cd5b3e5.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8475ad005858e3034823c06cd7cce4c3',
      'native_key' => 'log_deprecated',
      'filename' => 'MODX/Revolution/modSystemSetting/203471f1f3b2a026edbd6edcabea4b67.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c6e78d33d8f1ff1ccbd500c3487bbdac',
      'native_key' => 'link_tag_scheme',
      'filename' => 'MODX/Revolution/modSystemSetting/7f47bc806d9766f4a03a4ffe2224a341.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47d85311dfe2c29275ad2d2ceeeccdb0',
      'native_key' => 'lock_ttl',
      'filename' => 'MODX/Revolution/modSystemSetting/760288da85a8c399c736fcfeeab81391.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4346068dbb155e2685770895848cc177',
      'native_key' => 'mail_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/23dc5b8b9527e162c204df96f3b31cc4.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2977324f09e6b39446a5e8b8f6c6a838',
      'native_key' => 'mail_encoding',
      'filename' => 'MODX/Revolution/modSystemSetting/8bf464fadc5b338cac29876642582d19.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1da1cd7422f2c0c8a8ad41fdc89cd434',
      'native_key' => 'mail_use_smtp',
      'filename' => 'MODX/Revolution/modSystemSetting/e06d3784c4d30852ea59c1b1b1db25df.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd6077b53893e7781448fc35a8dbc2cb4',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'MODX/Revolution/modSystemSetting/9b7a1adaf86f8492bd8a6c9c2360b914.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '67c6de35f09abbede2c51af90a137c62',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'MODX/Revolution/modSystemSetting/f54c71cf44c87a0bddeeb7d3e9d4167b.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '521bd97b63f19c745e210c21822ee709',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'MODX/Revolution/modSystemSetting/7cb97723b22a53266d413e1efc9e30e5.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '492b674863061733d46bf009b5fd0d26',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'MODX/Revolution/modSystemSetting/b2b2700423d3845a8849413174de9db9.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a4db84c7a04ddc1332f0fa7a59c3aa02',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'MODX/Revolution/modSystemSetting/c426e999678594af43f5c789aa8fd3f6.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b7d8d9996334b81f4f24763ec516c468',
      'native_key' => 'mail_smtp_port',
      'filename' => 'MODX/Revolution/modSystemSetting/02f5977d01ad591fe3d46e90be5f0de5.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbc90d488b59a3c62a30b82a8d68aec4',
      'native_key' => 'mail_smtp_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/05e8c1224993acbcfe95a12ddb525716.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be4a95cc397c6c42d27a165d655346eb',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'MODX/Revolution/modSystemSetting/80ee7e85a7c455bfc94b594a2e3e753d.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7db4c154e49425f4e2e10cdb1c50eea8',
      'native_key' => 'mail_smtp_autotls',
      'filename' => 'MODX/Revolution/modSystemSetting/4f101e5d09e5e54f068091510ef828d0.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee7f59bdbc0db3cc5f70fcdc9adab40b',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'MODX/Revolution/modSystemSetting/6ef04ca6037bfceb935bd15906368366.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '41d3732cf4124ff5a544da2edda5c268',
      'native_key' => 'mail_smtp_user',
      'filename' => 'MODX/Revolution/modSystemSetting/cfedc5041a582ed712b04a33ed9599a1.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '9d999d17dd11a4461f6461627b1d80cb',
      'native_key' => 'manager_date_format',
      'filename' => 'MODX/Revolution/modSystemSetting/a7930c021f1b88103f821e39ec858213.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bcb2fe61f9188ab23917bf92aa57ac77',
      'native_key' => 'manager_favicon_url',
      'filename' => 'MODX/Revolution/modSystemSetting/fb9836b1c1b4dbf2fceb3f1a2b889c4c.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b2d998ecc9c976182a51004bc9398987',
      'native_key' => 'manager_time_format',
      'filename' => 'MODX/Revolution/modSystemSetting/5605bf0d9463c5b8f96d0d12297e5278.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '25123b4d3bea2a18b95002d877df1b9a',
      'native_key' => 'manager_direction',
      'filename' => 'MODX/Revolution/modSystemSetting/4b4d7fb038a46f6a232527dee2d167d0.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '346614f870d893e7297990c12c89f2ec',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'MODX/Revolution/modSystemSetting/b6b48c52d1add39ec7157a76b2abe88f.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8546713ba2d0fa1d69553fb89ab1b458',
      'native_key' => 'manager_tooltip_enable',
      'filename' => 'MODX/Revolution/modSystemSetting/6117eb9b749c61d8ab59f82567d159c2.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2f305401af8383029cca4ef2a666fb07',
      'native_key' => 'manager_tooltip_delay',
      'filename' => 'MODX/Revolution/modSystemSetting/b67d87fa6ff72b8c565ae030a72a8531.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c19db9d06e3c84e93349c9f2de66a164',
      'native_key' => 'login_background_image',
      'filename' => 'MODX/Revolution/modSystemSetting/745edf0bc199d8a60c13e034df662444.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1585c5874a915f38845de458bf428080',
      'native_key' => 'login_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/b62d9f371397f6266e802618181fa21b.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '070317bad086b65dda40e1328ea57aaa',
      'native_key' => 'login_help_button',
      'filename' => 'MODX/Revolution/modSystemSetting/496d8769bccc8498e4da8907537e61aa.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ea074f1b3dc9491b04d935feb7c96eab',
      'native_key' => 'manager_theme',
      'filename' => 'MODX/Revolution/modSystemSetting/1b3ccead2bbcebb0b473ceaf83a4b02a.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a1adb83e356180467f3b1cad13466dc1',
      'native_key' => 'manager_logo',
      'filename' => 'MODX/Revolution/modSystemSetting/d2f3aebf256a3904e738e155313b5fb5.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6d4d67082f4c10a6bd1c45bfefcb5d88',
      'native_key' => 'manager_week_start',
      'filename' => 'MODX/Revolution/modSystemSetting/6ffbbc0e5eff9601450540c6d064052b.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bf2bb562cb04a0a2387a7d591f40ba72',
      'native_key' => 'enable_template_picker_in_tree',
      'filename' => 'MODX/Revolution/modSystemSetting/490a47dd9bddfb4d93869579dbbf3555.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f301366b893771d04d5ab0d58b64878b',
      'native_key' => 'modx_browser_tree_hide_files',
      'filename' => 'MODX/Revolution/modSystemSetting/1c1871cea3bce92c44676b2210851fac.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3b4c6a9a2fece1afba52f9810eb64227',
      'native_key' => 'modx_browser_tree_hide_tooltips',
      'filename' => 'MODX/Revolution/modSystemSetting/3fa6adb99a0eba1551d6e00063e8c43a.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '788eaa82935f885e1ea7c60d03a0bc7f',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/465d19c8f618d2409e4d9b0129716424.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3850489d9b187e7867e7906cce48e713',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'MODX/Revolution/modSystemSetting/02c0ad31b39978146c01d7d39fd63f19.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '294e884863084b15491db070fe0b870d',
      'native_key' => 'modx_charset',
      'filename' => 'MODX/Revolution/modSystemSetting/5b1b49f9a7ed491422c70e4531ab81aa.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57e0edcaed7e8b45a22dbc08fea140a7',
      'native_key' => 'principal_targets',
      'filename' => 'MODX/Revolution/modSystemSetting/cc5561be104b7f4c3db75136b6990bde.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b4e7a24bfc451a6e6346da68a64a2ff0',
      'native_key' => 'proxy_auth_type',
      'filename' => 'MODX/Revolution/modSystemSetting/c1272ff2a405458b164c9bb104670ccb.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '50858c42d5d864cf88d915a2d43a367b',
      'native_key' => 'proxy_host',
      'filename' => 'MODX/Revolution/modSystemSetting/730e4e3a36f2bb1b1b52f5846d427cb2.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c71e952a34f3b206b61cb06c0da63479',
      'native_key' => 'proxy_password',
      'filename' => 'MODX/Revolution/modSystemSetting/31c46ddf27e797182db092a698d80197.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '966b00585ab2edaa687061bab17a51ec',
      'native_key' => 'proxy_port',
      'filename' => 'MODX/Revolution/modSystemSetting/ba9e9ed8bf9435dd9ca8c0f3ead3c519.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c22d6429f5e0510627443e699cd1531',
      'native_key' => 'proxy_username',
      'filename' => 'MODX/Revolution/modSystemSetting/01b9125b47ad43e104f33480f8f7ce82.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e82fd3d42093c9311c9a22829214eed2',
      'native_key' => 'password_generated_length',
      'filename' => 'MODX/Revolution/modSystemSetting/8f537c94a3a3e4d3b988d8f24ae3976b.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '197eb01e0eb5b2466f8c258d3a4bb481',
      'native_key' => 'password_min_length',
      'filename' => 'MODX/Revolution/modSystemSetting/4e9caf5b38d7074c73a5662d858d8256.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '522b6fc182751cf2e83ff66dedfb9b93',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'MODX/Revolution/modSystemSetting/d1925df756512fdf1666df0490c372ca.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd669cc6bf5b033c2adf5ca5c2f1bea0d',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'MODX/Revolution/modSystemSetting/0e828ec07e4d8f12823db27d7da830ad.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e6cfd3cfbdb303598f69e1df74c977e8',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/6ff955e356f2c6a5d1088e1a5cfc9915.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b345f74a9ef10c23f8f67627e536d523',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'MODX/Revolution/modSystemSetting/8e487ba6f7365af2b47657a0f41073a0.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3a0a1209800d3986cb0b8202ef72f2a8',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/88892154f73bad7060e8ac58802d8490.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a624765eb0b11c12898530054ad26150',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'MODX/Revolution/modSystemSetting/eff2016ccd70b8cd13a13fbf4200a1e9.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dd94ff0e6904c5bafc3aacf6cb9cad4d',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/7e756d3f1a202d6ce1ad0239ed6a6132.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '91acaaa13d987c1461e351a611121fc1',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'MODX/Revolution/modSystemSetting/11bd601b3d7f83128998c7054aab4d19.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd2b57a30834cc83b04da0d398cd537f7',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'MODX/Revolution/modSystemSetting/80791524701a91892ae98f32a894241c.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6f1fd17a3c0a10924bc9fef32397ce72',
      'native_key' => 'phpthumb_far',
      'filename' => 'MODX/Revolution/modSystemSetting/5c1c6c398a39f042ad7020380fa183aa.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '675027e2cc87f4e7f0671e607bdfb114',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'MODX/Revolution/modSystemSetting/7a866ede4022af30baf69a0d787a2369.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c289fcec2c329583bfcf5d896c1982b0',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/ee2d4b0413cdcdd64e0c56c9e2033a02.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '42ab8a67a5a0bd27ca2439ef44d8f558',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/c51464c6c580501bdb7300d926c65c0f.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '77569e9e85225d21780eca06ddcd1c93',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/77b53f31a40ba02a39a280a2a2503098.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32c15213dd04c974deef33a3f1e2a7af',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/50a2668f977a811ddccbafc14c351ada.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6aec8ea565da1a867aa3c099e75a0338',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'MODX/Revolution/modSystemSetting/59c99987cb671815f925be9b1932db80.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '912937054a4568b411aea58c2e0a5899',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'MODX/Revolution/modSystemSetting/8c481f361444690db545d415bb2a3375.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b91bd7c2f36ff4482f5f5f3693e6c6d3',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'MODX/Revolution/modSystemSetting/2b6b03bc2567d629b9ed024a31df83f4.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fe862e0b03cc8741912f6d6aa1dd8bd3',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'MODX/Revolution/modSystemSetting/72fed708ae78b207e459a476cd79746c.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6200873f005ce8b14d080ac6cb6a800d',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'MODX/Revolution/modSystemSetting/e1668c325bd929addc0e3f736a81d63a.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '4f21e903ad6c131881091540436005f9',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'MODX/Revolution/modSystemSetting/e36170a27672c47ebc4aa828307b2095.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ce6fba6b934152cd0fc6c3bf94539ee2',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'MODX/Revolution/modSystemSetting/1160c59e236fbccb1245fd038bee6e4e.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'aaf00bd7045f797b18b226d0ab49bf84',
      'native_key' => 'publish_default',
      'filename' => 'MODX/Revolution/modSystemSetting/d08e4f6e17beea28b15f2fd61968b9f4.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '74313fd01849060dd54d4f090e5a3641',
      'native_key' => 'quick_search_in_content',
      'filename' => 'MODX/Revolution/modSystemSetting/01b8f8d23bd2e23e07bbae6da0a7e696.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '59f34f6529d993c934f714c00632a55d',
      'native_key' => 'quick_search_result_max',
      'filename' => 'MODX/Revolution/modSystemSetting/d58efe991c87e6e23ca41a95732f4350.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e906d97cb1ebd2b2ff46f35442bbf233',
      'native_key' => 'request_controller',
      'filename' => 'MODX/Revolution/modSystemSetting/3b1076056986e1bb84bfab2c58f8f8f7.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad1e01240b7bbbd73e7ffa3cd308f3fd',
      'native_key' => 'request_method_strict',
      'filename' => 'MODX/Revolution/modSystemSetting/8ffb4f4b0986e30fe9c7e0be4abb9d96.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5ccc8ae5d820af03af300b58cff0769d',
      'native_key' => 'request_param_alias',
      'filename' => 'MODX/Revolution/modSystemSetting/0153c52bfaf395cf5525dc4c6e5f4a7c.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '405c83264f7d508c4ef8a6ba0ba25e34',
      'native_key' => 'request_param_id',
      'filename' => 'MODX/Revolution/modSystemSetting/c9004812b4da2254c634cb500953036c.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b2741c39bd3dfd74323ea60edff372f2',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'MODX/Revolution/modSystemSetting/2b9e94fbf25861aa194324fd2d2eb452.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3c0d17beb5402f488cb4a4b5d3edaef4',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'MODX/Revolution/modSystemSetting/dc28421e5c9d52cac99d6026ea000156.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'cc2c7b1dc44c811dc566495cf6a0e287',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'MODX/Revolution/modSystemSetting/0175d6b7b6bf22f87a1ab4db5a744c28.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '14fb2835ebb662f09d3333ba86d0dab3',
      'native_key' => 'richtext_default',
      'filename' => 'MODX/Revolution/modSystemSetting/6b618b0fff574cbdd66f4ff4ab3ae5c3.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '15c95a35cf79766e23c4997a08359c4e',
      'native_key' => 'search_default',
      'filename' => 'MODX/Revolution/modSystemSetting/eeb0e253de39d0291c04c42b40c4f823.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd8c5602346926a0f907e4651bef9dae8',
      'native_key' => 'server_offset_time',
      'filename' => 'MODX/Revolution/modSystemSetting/b56c9a06e533798aeca2ab1f48a15aac.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'b9bfd400e2cef8607afd6642a17bcc92',
      'native_key' => 'session_cookie_domain',
      'filename' => 'MODX/Revolution/modSystemSetting/47061b65580db67a520cf41b1d2f3955.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8ce51b466492d53eb4e7ac83ea76f6ac',
      'native_key' => 'default_username',
      'filename' => 'MODX/Revolution/modSystemSetting/00cfdbad945ceeb23c16b9990d7c26a2.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'faf87648ca0a3899108ae68a1784dc69',
      'native_key' => 'anonymous_sessions',
      'filename' => 'MODX/Revolution/modSystemSetting/1919724ec63b756365912b9e6c90232f.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8d2d7842f18477d3c33f127fe855f3bc',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/4e01d842bda72751d56bb4245e60ad11.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ea6cbe659274c75aa91e43b39ee99385',
      'native_key' => 'session_cookie_path',
      'filename' => 'MODX/Revolution/modSystemSetting/45467e8b2880dc9828b9a9d017622716.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5fcd199b49e69d5d824dd273d405ba4d',
      'native_key' => 'session_cookie_secure',
      'filename' => 'MODX/Revolution/modSystemSetting/6e09efd2364c2d9fde8ec8f9bf7240fd.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'daab49e994ef07dd8b065177a94869d8',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'MODX/Revolution/modSystemSetting/4e94ac2ab96f0b4bc8bff4c96dde02c7.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '82667be695e14bc4a40f8affd53dfe5f',
      'native_key' => 'session_cookie_samesite',
      'filename' => 'MODX/Revolution/modSystemSetting/9e20c70b1dead86f6ff4e167f3678ac2.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a398b5ff0f9a1dc2e4529edb61c02dfe',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'MODX/Revolution/modSystemSetting/16755e4e37fb0a988ff973dc4b2a97e0.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5186ec01c84d733c1e9a56da585ade96',
      'native_key' => 'session_handler_class',
      'filename' => 'MODX/Revolution/modSystemSetting/e41f7f8b9b10077cdf2e652659e08023.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47b6720c4c1b96d204b9859b426f1a4d',
      'native_key' => 'session_name',
      'filename' => 'MODX/Revolution/modSystemSetting/4683088e2011dda3aa849f81766e000c.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '68e1faa56a88f357f754ac9452bc307e',
      'native_key' => 'set_header',
      'filename' => 'MODX/Revolution/modSystemSetting/7924544bc8c762b7b0894390e49169f9.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ad7da4b7f935ae8c68ef39acb3e59693',
      'native_key' => 'send_poweredby_header',
      'filename' => 'MODX/Revolution/modSystemSetting/cc1b358f940cd9e4691ace424764d525.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '1d6849635f01474cb657640feed0cad6',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'MODX/Revolution/modSystemSetting/b3106662629cbc1cadcb6e2f6be274e8.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'be169d5753777cb7e64a12bd1e3907c0',
      'native_key' => 'site_name',
      'filename' => 'MODX/Revolution/modSystemSetting/289b16ce4f785e9389a2400567bb60c4.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ee9790be23a3d422f2c9c099ac3c58de',
      'native_key' => 'site_start',
      'filename' => 'MODX/Revolution/modSystemSetting/6f89c4f7ef01f1ec00b389f277b8e998.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '92322e3b4a37474f074d4c5c1e6102f0',
      'native_key' => 'site_status',
      'filename' => 'MODX/Revolution/modSystemSetting/2f88cfbdbcb734d2eeadd70bdade16e4.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '47cdd79bef50383c0b75c6436df29375',
      'native_key' => 'site_unavailable_message',
      'filename' => 'MODX/Revolution/modSystemSetting/48d9aa96c7669e43e1b077dcbb8022f8.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5e8902e17a7cd2ac5ce6a1ed502fd16a',
      'native_key' => 'site_unavailable_page',
      'filename' => 'MODX/Revolution/modSystemSetting/54e2e0d935ef62a8dbdfbd01f0a46331.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '712295af0e0c9cad3fc8df7b38686369',
      'native_key' => 'static_elements_automate_templates',
      'filename' => 'MODX/Revolution/modSystemSetting/00eda7bb6130cd78240c49ac9ef05872.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '99448e7b40e56687045bbfac249a6505',
      'native_key' => 'static_elements_automate_tvs',
      'filename' => 'MODX/Revolution/modSystemSetting/cc0f097c9abf77cc60b3930eb95ad5c4.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '282bb2d6a0676ae32f3dd697d4015aeb',
      'native_key' => 'static_elements_automate_chunks',
      'filename' => 'MODX/Revolution/modSystemSetting/9bfa26c6d6387947d1c0f7594ac94972.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f88f0d77ee74d63edac05a45794cc61f',
      'native_key' => 'static_elements_automate_snippets',
      'filename' => 'MODX/Revolution/modSystemSetting/77c301523e839e2369b2791ef820fa06.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '32d1329ebf24bcfe60aae68e12ad636a',
      'native_key' => 'static_elements_automate_plugins',
      'filename' => 'MODX/Revolution/modSystemSetting/e6c6c541b9b34d8a3a5b21fe5f52d242.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '28aeb6c9180c180b79c9ab22b5a7602d',
      'native_key' => 'static_elements_default_mediasource',
      'filename' => 'MODX/Revolution/modSystemSetting/334058f3cc1e8282003d2707aa244eea.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c07e04ba0131cff902730c57ab1b1dd7',
      'native_key' => 'static_elements_default_category',
      'filename' => 'MODX/Revolution/modSystemSetting/b7a9fc1666b22fba971f71d6dfd44a0a.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'd4c6cbcecbf06e1f516be21ee6c2ff2b',
      'native_key' => 'static_elements_basepath',
      'filename' => 'MODX/Revolution/modSystemSetting/152d0159d8b076254ad93f3e0d923c42.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '53a5c936d55311644a0835f2aaea37f2',
      'native_key' => 'resource_static_allow_absolute',
      'filename' => 'MODX/Revolution/modSystemSetting/69ac64b232f6e9f8b9da69ec2662323a.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7c2cd58790cba3500dc990958f559024',
      'native_key' => 'resource_static_path',
      'filename' => 'MODX/Revolution/modSystemSetting/b9e47182fd36144a7401e3b74e2ae1f7.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '46f4b2a8bba4cc28f85d2fd91a7cee05',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'MODX/Revolution/modSystemSetting/b1c3e7cc9f5716aef5c9fd7b6edea6b6.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '05e14318db84d99343a114c11e3ed6ef',
      'native_key' => 'syncsite_default',
      'filename' => 'MODX/Revolution/modSystemSetting/b32e59c9c5971003a3cd1ee61f638343.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fdbb10deff01a91a18cccec59925013a',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'MODX/Revolution/modSystemSetting/2245af8388483e5cc035db968baf21eb.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'e515cb6fc43687bee2f56a2d0b910471',
      'native_key' => 'tree_default_sort',
      'filename' => 'MODX/Revolution/modSystemSetting/0522b55eb721ff23b2e16f71a64646d5.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f14dc32b5c42bcc82cbc197730027720',
      'native_key' => 'tree_root_id',
      'filename' => 'MODX/Revolution/modSystemSetting/e76c03fbabba566eb8bfdb5c9e682859.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'fab96bcf0ce6d0fe8aa242a37f785051',
      'native_key' => 'tvs_below_content',
      'filename' => 'MODX/Revolution/modSystemSetting/4645f89a7bb99aa28479ebb24452f05a.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6286983f532f6b42aae1525116098b6d',
      'native_key' => 'unauthorized_page',
      'filename' => 'MODX/Revolution/modSystemSetting/5443f1b3b1a333269e9ae8b8acdee5b2.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0987a456ae755ce0247c01431c3dcfde',
      'native_key' => 'upload_files',
      'filename' => 'MODX/Revolution/modSystemSetting/b1bf338d690ba36faaf81943f1b09701.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0867355260158458cb3ed0e1fa2881ca',
      'native_key' => 'upload_file_exists',
      'filename' => 'MODX/Revolution/modSystemSetting/67649b88cba951ccb95e63a5545dbb8c.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '30a46c3638f70a0e375a37264b189b72',
      'native_key' => 'upload_images',
      'filename' => 'MODX/Revolution/modSystemSetting/e1b87a0451f47f05a2128dd21cd0ab37.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a452b221228ece87a8a63780ec1a75d8',
      'native_key' => 'upload_maxsize',
      'filename' => 'MODX/Revolution/modSystemSetting/75c5daba79462396f768207bd488ffd9.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5336e6eaf3533fc9c6feaa4fc0bd27de',
      'native_key' => 'upload_media',
      'filename' => 'MODX/Revolution/modSystemSetting/8037d68133907da3ce13bf0e568ab2be.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '20c3b39a6adc0ccb6e1f1e90188511a6',
      'native_key' => 'upload_translit',
      'filename' => 'MODX/Revolution/modSystemSetting/4e2481c2114c114ecb215f08e21cb9aa.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '6ec677c3eeff16b4cdfdb5f113f2fce6',
      'native_key' => 'use_alias_path',
      'filename' => 'MODX/Revolution/modSystemSetting/f961d736bce606dbffa162b72b660e60.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0371f3f7545d3378873252c6d3bda0cf',
      'native_key' => 'use_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/4335bc423cb5d8c4f77af3b9f554ef7f.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'c666e6a67a43b29bb111c5fda5bdd7c0',
      'native_key' => 'use_multibyte',
      'filename' => 'MODX/Revolution/modSystemSetting/44867a6cbb81c578fd95c94dbca24241.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '8e350394fb9cb08db87aa3155c53ce06',
      'native_key' => 'use_weblink_target',
      'filename' => 'MODX/Revolution/modSystemSetting/4174f4c13fc0ce8c173e9b0a901bb32d.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5cf63eec6f7cebe5b4d913d5f71104d0',
      'native_key' => 'welcome_screen',
      'filename' => 'MODX/Revolution/modSystemSetting/956261d9d89edb1ea471da14c60fc813.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a2e02be51f30f417f5721d5d2497fefa',
      'native_key' => 'welcome_screen_url',
      'filename' => 'MODX/Revolution/modSystemSetting/d9f43f32783dadb685b7cbf63abef6c1.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'dbfe9dbb886df7a15ab3f60c9b142b2f',
      'native_key' => 'welcome_action',
      'filename' => 'MODX/Revolution/modSystemSetting/c7e77bb269a5d034ccb3895ac5c92304.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '56a5dca2a89c0ab7a7cb8d90ac4bdef7',
      'native_key' => 'welcome_namespace',
      'filename' => 'MODX/Revolution/modSystemSetting/8a36105a33afdc2c2b2498a405cbb155.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '03bbc9552b11f0c7d01ac78149c71906',
      'native_key' => 'which_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/90b3467f43669e7f6a457c24e97ba6a3.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '2e3172b3bf162f83d99f22a235851c96',
      'native_key' => 'which_element_editor',
      'filename' => 'MODX/Revolution/modSystemSetting/925b6a440eabbb951878cf39891b15de.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f87a767d9cca8721e076a405ecfeb2cf',
      'native_key' => 'xhtml_urls',
      'filename' => 'MODX/Revolution/modSystemSetting/b2d1e8b1fe4ee9e645d3893c5a3d2c39.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '3f983b0f47772232b1e07810b87b37b7',
      'native_key' => 'enable_gravatar',
      'filename' => 'MODX/Revolution/modSystemSetting/800c44deb7a7e719f9c78afe4918d9cf.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '02164f34f9925da165b489a1fffdb98a',
      'native_key' => 'mgr_tree_icon_context',
      'filename' => 'MODX/Revolution/modSystemSetting/eab52b78bce4b5592bfc1b514b39990e.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '5cf86733f568a9f9faa3abe93f64db0f',
      'native_key' => 'mgr_source_icon',
      'filename' => 'MODX/Revolution/modSystemSetting/96170b6812f8fe937b93290699952fa6.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '090cedbb299d044fab1b72b613e2bc07',
      'native_key' => 'main_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/5dc20460026c7b8cc08f7124ed47c371.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'bbfedf67fb664634acb7fdb1c9d29d99',
      'native_key' => 'user_nav_parent',
      'filename' => 'MODX/Revolution/modSystemSetting/3fc5503bf2f153611947510317ff7b27.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0beab46437ba23b37bf9034e64dacd4a',
      'native_key' => 'auto_isfolder',
      'filename' => 'MODX/Revolution/modSystemSetting/4af5196b28f559d2e74d8d6b525040b9.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '57c66059c4523142d913bbcc47c50ed4',
      'native_key' => 'manager_use_fullname',
      'filename' => 'MODX/Revolution/modSystemSetting/e78a35040e248889383d84113e1f3f1d.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'f3236a4307a69a75e89b73b18addd86c',
      'native_key' => 'parser_recurse_uncacheable',
      'filename' => 'MODX/Revolution/modSystemSetting/391ffbf900a5e780ac34f5fa923a0516.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '90061f7d6d6022994ea871a85499e747',
      'native_key' => 'preserve_menuindex',
      'filename' => 'MODX/Revolution/modSystemSetting/fdcac689be1a3011957e0ee140bbddcf.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '7884b22af23b5fc39453f9f0575a9ffc',
      'native_key' => 'log_snippet_not_found',
      'filename' => 'MODX/Revolution/modSystemSetting/3a57f1ee7494393d098c17c2359e807e.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '34e99499ff61c26c9023503b3ecbdfd3',
      'native_key' => 'error_log_filename',
      'filename' => 'MODX/Revolution/modSystemSetting/99ac21ef4411004330919b5a67526bbd.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'ec20953b2d811a9689804f7f92fcbe8b',
      'native_key' => 'error_log_filepath',
      'filename' => 'MODX/Revolution/modSystemSetting/cbac30de74db6e283300e3607e992f86.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => 'a7a843e8d88a2ef2411b654aa3cfff67',
      'native_key' => 'passwordless_activated',
      'filename' => 'MODX/Revolution/modSystemSetting/74a8ca97ca4537e85715fcffa0dba6a1.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '0ffb3b618c40457203c8a233495070d0',
      'native_key' => 'passwordless_expiration',
      'filename' => 'MODX/Revolution/modSystemSetting/e2634bdf3aeaaea55f0b9ca79da70e43.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modSystemSetting',
      'guid' => '68956acabd44994a402baa16afd6b984',
      'native_key' => 'static_elements_html_extension',
      'filename' => 'MODX/Revolution/modSystemSetting/581ed40a35fdb344bb2f92e5ef32f932.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => '1ab705c4334c970289dee1c45df25f81',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/99a57569b48fc1d05297130b930d889a.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContextSetting',
      'guid' => 'b67e36e1648b8dfddca06548e99d8c0a',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'MODX/Revolution/modContextSetting/4ac1d2767a6ba1c967af3c9246f323c3.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroup',
      'guid' => '3566b3fad04e945f68cb72d68b792154',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroup/f308c5d17e933ae0d2aa0ad7deee822d.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboard',
      'guid' => 'cd02ec311cae74b6e9fe418ee4c67017',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modDashboard/0c090b0b2f0fbfee9e58ee17676305e4.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\Sources\\modMediaSource',
      'guid' => '4b3d406d3747d27eb8d799a18c32e3a7',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/Sources/modMediaSource/36bea9ec789df877d0a89cf6f5248574.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'bf338fde1f7ac0274130c310cc305bad',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/8235334553ec33f2c269cc96147fc419.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '1531e191c19e6806777422e1ef9c8a60',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/91aa1765c437b0bd5d495a7c1a721f2d.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '9e9d83182c9e44ae344774b7a34ae7c8',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/224c9d850aad89911f1759f162359585.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'b2eb21e921233e16aae985dd70c78a32',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/6b8ced805662799d3c6973517aa4fbd3.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '84d89a6c9499448ff52238a0a28fdd6f',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/c1d4b864ca0a8c268a36c0c2f6ef1165.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => '2655bc7d32cb755716e0cc5e33427ae1',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/a023c5cc754033a63c97ea69d9bf6d0f.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modDashboardWidget',
      'guid' => 'd9abbeedd329ff6bd5363c2858fd4191',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modDashboardWidget/acc3708f036b9296935e15c0bd30ea34.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => '4ffa5908bd754d6c0bd0cb87b3197986',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modUserGroupRole/b9ea7c6476cc88de80d54cf32566898b.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modUserGroupRole',
      'guid' => 'fc098da41f0a00cf32422d12d32e62a4',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modUserGroupRole/0efefeebf9108cf75958345669096d68.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '87948306bd186bb7a631b411e173cc91',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/b44ba6361e8701b862148daee585c88a.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'afc0de5b8d4ffd843c1ef440bffcb6d2',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/9782c67612905ce9bda5156d6abe548b.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '136e9ac586f0cbac874f104dee8d9c53',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/408d3b17eac1ae61a5407575a054552f.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '8d4300620a9dd82d2c4f15fbca2d0c78',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/0648816233927ac12772a6afd827ff68.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => 'a94a16fafa868266e8c2603caff649bf',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/2637860e0eeec161271826e33794b57a.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '50fb4ae371d9f69c47916459c49bd410',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/8710c4c821956c8f7fe2642d53c59e39.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplateGroup',
      'guid' => '26f8bdd3e743e59aead0a6e3f2e36f13',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplateGroup/bbdd84f4bde5984230497b623231946f.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'bc2572683856adfca07f3b99e4eb1750',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/8189856383ec0f6556e217b22b219b29.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '314d5966ffd6490d26e2f7a9f196d4cb',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/1a0c733786fe7a57ee51e200c53c2f34.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '2fc8502f520134a9f17111680b6524ee',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/88627364db59ea418d58ddba1be8aaf3.vehicle',
    ),
    456 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '7ab53765a3d0929e639a5473f9e91f23',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/d7690ef1eebbd75dc565357b0787ac7a.vehicle',
    ),
    457 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '22aac046cf373f71629d4683d8f633b5',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/c63f1bfb81005fee7523b7aecdb82320.vehicle',
    ),
    458 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => '9a008137e8f55271cab6c045d137c4e3',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/28e70dbbb8382a65386a2b97c0c44e8d.vehicle',
    ),
    459 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicyTemplate',
      'guid' => 'd20b4333d0e482fbb268088346ca73ea',
      'native_key' => NULL,
      'filename' => 'MODX/Revolution/modAccessPolicyTemplate/604eb720a27361171916840f301eecb3.vehicle',
    ),
    460 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '045d62feda0b552e2ea74cd8cd072d78',
      'native_key' => 1,
      'filename' => 'MODX/Revolution/modAccessPolicy/b86b5aac2059c68c8cbb053de9e2187d.vehicle',
    ),
    461 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'ba774b50e59b6605b3de8600b4c1e66c',
      'native_key' => 2,
      'filename' => 'MODX/Revolution/modAccessPolicy/cb350ebb331370381ab9a0fc665d005c.vehicle',
    ),
    462 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'd472a400ac0a2b93f1032bf72d43545a',
      'native_key' => 3,
      'filename' => 'MODX/Revolution/modAccessPolicy/c4d8b311f3a043cd7513365dbf9c410b.vehicle',
    ),
    463 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '4e9d0eb3d466e56a522056cde35146d1',
      'native_key' => 4,
      'filename' => 'MODX/Revolution/modAccessPolicy/31b5b981e9cece76baa5d59a4548498f.vehicle',
    ),
    464 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '5a5d0957558bb98f518ad2ddf5609db0',
      'native_key' => 5,
      'filename' => 'MODX/Revolution/modAccessPolicy/070095f4440101117a61599be9b8b2d7.vehicle',
    ),
    465 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '312504118cefec50f32eeccfd5d6f041',
      'native_key' => 6,
      'filename' => 'MODX/Revolution/modAccessPolicy/e9f0b436f00e1cd75bc3708e65703007.vehicle',
    ),
    466 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '1e9bac98352c0d0598b5aa767013bf21',
      'native_key' => 7,
      'filename' => 'MODX/Revolution/modAccessPolicy/6036c9b97e26c07c80ff435724ed26e7.vehicle',
    ),
    467 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6e1e9d0ada68bb800d2e0c36afb4c1e2',
      'native_key' => 8,
      'filename' => 'MODX/Revolution/modAccessPolicy/96dc698a9bdfce8cfccc1077bfdd6397.vehicle',
    ),
    468 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '8166e07e12f6fb78a57d6654e4c593b6',
      'native_key' => 9,
      'filename' => 'MODX/Revolution/modAccessPolicy/c81c0f9f5a600ceb4feb5d3db59f1d48.vehicle',
    ),
    469 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'c81bce7b62ff173899ec06ae1b4ce8cd',
      'native_key' => 10,
      'filename' => 'MODX/Revolution/modAccessPolicy/9ad6c7754add1f0cdcd367130c4cdbef.vehicle',
    ),
    470 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => '6cdaa7be28803c0827760a0aec5f9640',
      'native_key' => 11,
      'filename' => 'MODX/Revolution/modAccessPolicy/b487683795702310c822a45cbae68db3.vehicle',
    ),
    471 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modAccessPolicy',
      'guid' => 'de8c7030315100ba14e542bd38ecfa3d',
      'native_key' => 12,
      'filename' => 'MODX/Revolution/modAccessPolicy/a08ad3c26b96c47507b51a5f60385464.vehicle',
    ),
    472 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => '73bc157bce2aaaaecea22d68a1d9f458',
      'native_key' => 'web',
      'filename' => 'MODX/Revolution/modContext/75fcae795b89e8db3089bb0266bd1714.vehicle',
    ),
    473 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'MODX\\Revolution\\modContext',
      'guid' => 'c29b5c3092282053f4ea1f5989b63ba3',
      'native_key' => 'mgr',
      'filename' => 'MODX/Revolution/modContext/c500e1ecb26fdcbed5be0ee12958c66a.vehicle',
    ),
    474 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '9c7834817c08773286ba9338593ba299',
      'native_key' => '9c7834817c08773286ba9338593ba299',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/093f647ff7c499693575fc31ed1d2791.vehicle',
    ),
    475 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '58fd5165556ace0c3f4998bd0c8e55f7',
      'native_key' => '58fd5165556ace0c3f4998bd0c8e55f7',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/f225e41fdfc3c48c58f2a932cbe37add.vehicle',
    ),
    476 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => 'd196fb7817c4c91fa6b47eaef4cd3aae',
      'native_key' => 'd196fb7817c4c91fa6b47eaef4cd3aae',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/fdea91019c5b0d5200020626619f99ef.vehicle',
    ),
    477 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'class' => 'xPDO\\Transport\\xPDOFileVehicle',
      'guid' => '5a70a02befbfadc6b7bbc46b233e6650',
      'native_key' => '5a70a02befbfadc6b7bbc46b233e6650',
      'filename' => 'xPDO/Transport/xPDOFileVehicle/1b345cf643df45df7816d499c889d5a5.vehicle',
    ),
  ),
);